package TestPageScenario;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import BaseClassDriver.DriverClass;
import GeneralFunctions.Basicfunctions;
import BaseClassDriver.DriverClass;
import GeneralFunctions.Basicfunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import TestPages.*;

public class HomePage_Operation extends DriverClass {
		
	protected Basicfunctions keys = new Basicfunctions(driver);

	private RespositoryParser parser;;
	
	public String search_content, product_name;
	WebDriverWait wait;

	public HomePage_Operation(AppiumDriver driver) throws IOException {
		log.info("Loginpage elements initialized");
		System.out.println(System.getProperty("user.dir"));
		parser = new RespositoryParser(System.getProperty("user.dir") + "/util/testdata.properties");
	}

	
	public void scrollforanitem(String item) throws InterruptedException, IOException {
		wait = new WebDriverWait(driver, 10);
		keys.scrollToText(item);
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator(item)))));
		log.info("");
		
	}

}
