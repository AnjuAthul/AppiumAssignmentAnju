package TestPageScenario;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.Assert;

import BaseClassDriver.DriverClass;
import GeneralFunctions.Basicfunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseClassDriver.DriverClass;

import TestPages.RespositoryParser;

import GeneralFunctions.Basicfunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPage_login extends DriverClass {
	
	protected Basicfunctions keys = new Basicfunctions(driver);
		public String username;
	WebDriverWait wait;
	private RespositoryParser parser;;
	
	
	public LoginPage_login(AppiumDriver driver) throws IOException {
		
		log.info("Loginpage elements initialized");
		System.out.println(System.getProperty("user.dir"));
		parser = new RespositoryParser(System.getProperty("user.dir") + "/util/testdata.properties");
	}
	
	public void login_validtest() throws InterruptedException, IOException {

		wait = new WebDriverWait(driver, 59);
		log.info(getClass());
			log.info("Retreiving Username from property file");
			
		//driver.switchTo().alert().accept();
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("accountbutton")))));
		log.info("Clicked  account button from homepage successfully");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("signinbutton")))));
		log.info("Sign in button is clicked successfully");

		
//
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("cancelthepopup")))));
		log.info("Clicked cancelling for the pop up successfully");
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("usernameelement")))),parser.getvalue("username"));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("viapassword")))));
		log.info("Clicked continue successfully");
		
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("passwordelement")))),parser.getvalue("password"));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("loginbutton")))));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("smartlockok")))));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("accountbutton")))));
		log.info("Clicked  customer signin successfully");
		
		Boolean cc=driver.getPageSource().contains(parser.getvalue("username"));
		Assert.assertTrue(cc);
		
log.info("Successfully Logged in with valid credentials");

	}
	public void login_Invalidtest() throws InterruptedException, IOException {

		wait = new WebDriverWait(driver, 59);
		log.info(getClass());
			log.info("Retreiving Username from property file");
			
		//driver.switchTo().alert().accept();
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("accountbutton")))));
		log.info("Clicked  customer signin successfully");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("signinbutton")))));
		log.info("Sign in is clicked successfully");

		
//
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("cancelthepopup")))));
		log.info("Clicked continue successfully");
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("usernameelement")))),parser.getvalue("Invalidusername"));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("viapassword")))));
		log.info("Clicked continue successfully");
		
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("passwordelement")))),parser.getvalue("Invalidpassword"));
		log.info("Clicked continue successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("loginbutton")))));
		log.info("Clicked continue successfully");
			
		Boolean cc=driver.getPageSource().contains("Incorrect login details");
		Assert.assertTrue(cc);
		
log.info("invalid credential login gets failed");

	}

	public void logout() throws InterruptedException, IOException {

		wait = new WebDriverWait(driver, 59);
		
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("accountbutton")))));
		log.info("Clicked  customer account successfully");
		keys.Tapwithcodinates(228, 942);
		keys.scrollToText("Sign Out");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("signout")))));
		log.info("Clicked log out button successfully");
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(driver.findElement(parser.getbjectLocator("signoutconfirm")))));
		log.info("Clicked log out button successfully");
		Boolean cc=driver.getPageSource().contains("Hi Guest");
		Assert.assertTrue(cc);	
		log.info("Logged out from the application successfully");
	}

}