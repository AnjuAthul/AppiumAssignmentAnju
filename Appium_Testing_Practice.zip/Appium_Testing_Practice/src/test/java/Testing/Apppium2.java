package Testing;



import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.remote.DesiredCapabilities;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;


import java.awt.Dimension;

import java.net.MalformedURLException;

import java.net.URL;

import java.time.Duration;


import io.appium.java_client.android.nativekey.AndroidKey;

import io.appium.java_client.android.nativekey.KeyEvent;


import io.appium.java_client.PerformsTouchActions;

import io.appium.java_client.TouchAction;

import io.appium.java_client.touch.WaitOptions;

import io.appium.java_client.touch.offset.PointOption;



//initialize AppiumDriver



public class Apppium2 {


    public WebDriver driver;

    public WebDriverWait wait;

 

   


    @BeforeMethod

    public void setup () throws MalformedURLException {

        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("no",true);

        caps.setCapability("deviceName", "Test");

        caps.setCapability("udid", "520090dd4b40353b"); //DeviceId from "adb devices" command

        caps.setCapability("platformName", "Android");

        
        caps.setCapability("platformVersion", "9");

        caps.setCapability("skipUnlock","true");

        //caps.setCapability("appPackage", "com.android.calculator2");

        //caps.setCapability("appActivity","com.android.calculator2.Calculator");

        caps.setCapability("appPackage", "com.android.settings");

        caps.setCapability("appActivity",".Settings");

        caps.setCapability("noReset","false");

        driver = new AndroidDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"),caps);

        //driver = new RemoteWebDriver(new URL("http://localhost:4723/wd/hub"), caps);

        wait = new WebDriverWait(driver, 10);

       

     

        

        

    }



    @Test

public void basicTest () throws InterruptedException {

     //driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.android.calculator2:id/digit_2']")).click();

     

     //Thread.sleep(1000);

     

     //driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.android.calculator2:id/op_add']")).click();

     

     //Thread.sleep(1000);

   

     

     

     //driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.android.calculator2:id/digit_4']")).click();

     

     //driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.android.calculator2:id/eq']")).click();

     

     //WebElement result = driver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.android.calculator2:id/result']"));

     

     //Thread.sleep(5000);


     //assert result.getText().equals("6"):"Actual value is : "+result.getText()+" did not match with expected value: 6";

    

    

    

    

    driver.findElement(By.xpath("//android.widget.TextView[@text='Battery']")).click();

    

    

    

    


    //((AndroidDriver<?>) driver).pressKey(new KeyEvent(AndroidKey.HOME));

    

     

     //driver.findElement(By.id("com.android.calculator2:id/digit_2")).click();

     Thread.sleep(5000);

    

     

   

     

   

     

     

    

     

     

     

     //driver.findElement(By.id("com.android.calculator2:id/op_add")).click();

    }

    

   

    

    

    

    

    

 

    

 



@AfterMethod

    public void teardown(){

        driver.quit();

    }

}


