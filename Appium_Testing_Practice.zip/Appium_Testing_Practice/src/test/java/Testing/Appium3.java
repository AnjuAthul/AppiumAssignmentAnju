package Testing;

import org.testng.annotations.Test;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.awt.Dimension;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;


//initialize AppiumDriver


public class Appium3 {

    public WebDriver driver;
    public WebDriverWait wait;
 
   

    @BeforeMethod
    public void setup () throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("no",true);
        caps.setCapability("deviceName", "Test");
        caps.setCapability("udid", "emulator-5554"); //DeviceId from "adb devices" command
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "8.1.0");
        caps.setCapability("skipUnlock","true");
        //caps.setCapability("appPackage", "com.android.calculator2");
        //caps.setCapability("appActivity","com.android.calculator2.Calculator");
        caps.setCapability("app","/Users/praveenkumar/Desktop/Demo/MyTelstra.apk");
        caps.setCapability("appPackage", "com.telstra.mobile.android.mytelstra");
        caps.setCapability("appActivity","com.telstra.android.myt.main.MainActivity");
        caps.setCapability("noReset","false");
        driver = new AndroidDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"),caps);
        //driver = new RemoteWebDriver(new URL("http://localhost:4723/wd/hub"), caps);
        wait = new WebDriverWait(driver, 10);
       
     
       
       
    }


    @Test
public void basicTest () throws InterruptedException {
   
    Thread.sleep(5000);
   
    driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.telstra.mobile.android.mytelstra:id/next']")).click();
   
    Thread.sleep(1000);
    driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.telstra.mobile.android.mytelstra:id/next']")).click();
    Thread.sleep(1000);
    driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.telstra.mobile.android.mytelstra:id/next']")).click();
   
   
   
   
   
   
    driver.findElement(By.id("com.telstra.mobile.android.mytelstra:id/close")).click();
    Thread.sleep(5000);
   
   
    //The viewing size of the device
         org.openqa.selenium.Dimension size = driver.manage().window().getSize();

         //x position set to mid-screen horizontally
         int width = size.width / 2;

         //Starting y location set to 60% of the height (near bottom)
         int startPoint = (int) (size.getHeight() * 0.60);

         //Ending y location set to 20% of the height (near top)
         int endPoint = (int) (size.getHeight() * 0.20);

         new TouchAction((PerformsTouchActions) driver).press(PointOption.point(width, startPoint)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(width, endPoint)).release().perform();

   
         Thread.sleep(5000);
   
         
   
   
   
   
   
    try {
     //  Block of code to try
    driver.findElement(By.xpath("//android.widget.TextView[@text='Shop']")).click();
    Thread.sleep(5000);
    Reporter.log("Successfully selected shop option");
    }
    catch(Exception e) {
     //  Block of code to handle errors
   
    Reporter.log("Failed to  select shop option");
    }
   
   
   
   
   
    }
   
   
   


 

@AfterMethod
    public void teardown(){
        driver.quit();
    }
}
