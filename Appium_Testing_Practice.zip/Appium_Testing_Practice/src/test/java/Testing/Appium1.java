package Testing;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Appium1 {
	static AppiumDriver<MobileElement> driver;
	public static void main(String[] args)
	{
		try {
			Opencalculatr();
		} catch (Exception e) {
			
			System.out.println(e.getCause());
			System.out.println(e.getMessage());
			e.printStackTrace();
			
		}
	}
public static void Opencalculatr() throws Exception
{
DesiredCapabilities cap= new DesiredCapabilities();
//cap.setCapability("deviceName", "Galaxy J1 Ace");
//cap.setCapability("udid", "110158b625c6334a");
//cap.setCapability("platformName", "Android");
//cap.setCapability("platformVersion", "4.4.4");
//cap.setCapability("appPackage", "com.hmh.api");
//cap.setCapability("appActivity", "com.hmh.api.ApiDemos");
////cap.setCapability("automationName", "UiAutomator2");
////
cap.setCapability("deviceName", "Galaxy J1 Ace");
cap.setCapability("udid", "520090dd4b40353b");
cap.setCapability("platformName", "Android");
cap.setCapability("platformVersion", "9");
cap.setCapability("appPackage", "com.sec.android.app.popupcalculator");
cap.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");
cap.setCapability("automationName", "UiAutomator2");

URL url = new URL("http://127.0.0.1:4723/wd/hub");
driver = new AppiumDriver<MobileElement>(url,cap);
System.out.println("Application Launched");
MobileElement aa = driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_09"));
aa.click();

//com.sec.android.app.popupcalculator:id/bt_08
}

}
