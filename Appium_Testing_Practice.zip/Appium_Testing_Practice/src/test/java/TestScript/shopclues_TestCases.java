package TestScript;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import BaseClassDriver.DriverClass;
import BaseClassDriver.DriverClass;
import TestPageScenario.HomePage_Operation;
import TestPageScenario.LoginPage_login;
import io.appium.java_client.AppiumDriver;

public class shopclues_TestCases extends DriverClass {
	
	@Test(priority=0 )
	public void tc001_Login_validCred() throws InterruptedException, IOException { // Interacting with login page
		LoginPage_login lp = new LoginPage_login(driver);
		lp.login_validtest();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}
	@Test(priority=1,dependsOnMethods ="tc001_Login_validCred")
	public void tc002_ScrolldowntoselectTopsaree() throws InterruptedException, IOException { // Interacting with login page
		HomePage_Operation home = new HomePage_Operation(driver);
		home.scrollforanitem("Sarees");
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}
	@Test(priority=2,dependsOnMethods ="tc002_ScrolldowntoselectTopsaree")
	public void tc003_logoutfromapp() throws InterruptedException, IOException { // Interacting with login page
		LoginPage_login lp = new LoginPage_login(driver);
		lp.logout();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);


	}
		
	@Test(priority=3)
	public void tc002_Login_InvalidCred() throws InterruptedException, IOException { // Interacting with login page
		LoginPage_login lp = new LoginPage_login(driver);
		lp.login_Invalidtest();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}

	
}